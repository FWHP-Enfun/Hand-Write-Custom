包含以下文件或文件夹：
【data】离线数据，用于离线字体生成工具导入模板
【half_2in1】半版面手写模板(带参照页)，用于打印后手写，同时方便参照。
【characters.txt】当前模板的所有字符

说明：
还提供了全版面的A4通用手写模板，请通过下述的下载链接另行下载。全版面手写模板与半版面手写模板(带参照页)是一样的，任选其一打印后进行书写即可。也可以通过触屏电脑、平板电脑等带手写功能的电子设备进行书写，而不需要打印。

全版面通用模板下载：
http://font.meizhanggui.com/content/source/full_write.zip

如需详细帮助请进入网站：
http://font.meizhanggui.com

离线字体生成工具下载：
http://font.meizhanggui.com